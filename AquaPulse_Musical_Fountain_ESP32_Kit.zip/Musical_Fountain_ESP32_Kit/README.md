# AquaPulse — Musical Fountain ESP32 Prototype

A browser-based musical fountain controller with an 8-channel audio-reactive interface and ESP32 WebSocket receiver.

## What is included
- `website/` — water-themed website; load and play an audio file, analyze its frequency spectrum in the browser, visualize it, and send 8 jet levels (0–100) to ESP32.
- `esp32_firmware/` — Arduino sketch for an ESP32 Dev Module. It receives JSON over WebSocket port 81 and outputs PWM on eight GPIO pins.
- Manual mode, demo pattern, all-off and stop controls.

## 1. Prepare the ESP32
1. Install Arduino IDE and the ESP32 board package.
2. In Library Manager install **WebSockets** by Markus Sattler and **ArduinoJson** by Benoit Blanchon.
3. Open `esp32_firmware/AquaPulse_ESP32.ino`.
4. Edit `WIFI_SSID` and `WIFI_PASSWORD` to match your Wi-Fi router.
5. Select your ESP32 board and COM port; upload.
6. Open Serial Monitor at 115200 baud and note the ESP32 IP address.

This sketch uses `ledcAttach()` / `ledcWrite(pin, duty)`, which are for ESP32 Arduino core 3.x. If your installed ESP32 board package is 2.x, update it to 3.x or adapt the LEDC setup.

## 2. Run the website
The computer/phone and ESP32 must be on the same Wi-Fi network.

### Simple Windows method
1. Extract the ZIP.
2. Open the `website` folder in VS Code.
3. Open Terminal in VS Code and run:
   `py -m http.server 5500`
4. In the browser open:
   `http://localhost:5500`
5. Enter the ESP32 IP from Serial Monitor in the ESP32 IP field and click **Connect ESP32**.
6. Load an audio file and press Play. Keep the browser tab open.

You can also use VS Code Live Server. If the browser blocks a connection because of network policy, serve the site over localhost as above and check that the browser permits local-network WebSocket connections.

## 3. Wiring concept (low-voltage prototype only)
Each GPIO output is a 3.3V logic PWM signal. Connect it to a suitable MOSFET driver module input, not to a pump.
- GPIO 13, 14, 16, 17, 18, 19, 21, 22 -> driver inputs IN1..IN8
- Driver outputs -> compatible DC pump/valve loads
- Use a separate correctly rated DC supply for pumps.
- Connect grounds as required by the driver design; use suitable flyback suppression for inductive loads.
- Check pump/driver current ratings and whether the pump supports PWM speed control.

Do not use mains voltage or exposed mains wiring near water. Use an isolated, current-limited low-voltage supply for the demonstration. Keep all electronics dry and away from splashes. A physical emergency power disconnect should be available. The web stop button is not a certified safety system.

## Message format
The website sends one JSON message roughly every 50 ms:

`{"mode":"auto","stop":false,"jets":[0,22,40,65,70,45,18,5]}`

Each jet value is 0–100 percent. ESP32 maps it to an 8-bit PWM duty value (0–255). On stop, it writes zero to all outputs.

## Prototype limitations
- This is a model/demo controller, not a commercial fountain controller.
- Browser audio analysis works on audio played by this website. It cannot directly analyze arbitrary system/Bluetooth audio.
- Actual water height depends on pump curve, nozzle, pipework, back pressure and pump response. PWM does not guarantee a linear height change.
- Some DC pumps must not be PWM-controlled. Verify with the pump manufacturer; use a suitable driver or proportional valve.
- Add hardware-level interlocks and a physical emergency stop before any wet testing.
