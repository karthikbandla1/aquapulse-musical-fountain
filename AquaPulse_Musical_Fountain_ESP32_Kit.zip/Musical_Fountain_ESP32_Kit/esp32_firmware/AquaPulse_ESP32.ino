/*
  AquaPulse ESP32 receiver
  Libraries (Arduino Library Manager):
    - WebSockets by Markus Sattler
    - ArduinoJson by Benoit Blanchon
  Board: ESP32 Dev Module
  IMPORTANT: GPIO pins drive MOSFET/driver inputs only, never pumps directly.
*/
#include <WiFi.h>
#include <WebSocketsServer.h>
#include <ArduinoJson.h>

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
WebSocketsServer webSocket = WebSocketsServer(81);

const uint8_t JET_COUNT = 8;
const uint8_t jetPins[JET_COUNT] = {13, 14, 16, 17, 18, 19, 21, 22};
const uint32_t PWM_FREQ = 1000;
const uint8_t PWM_BITS = 8;
uint8_t jetValues[JET_COUNT] = {0};

void allOff() {
  for (int i = 0; i < JET_COUNT; i++) {
    jetValues[i] = 0;
    ledcWrite(jetPins[i], 0);
  }
}

void onWebSocketEvent(uint8_t client, WStype_t type, uint8_t * payload, size_t length) {
  if (type == WStype_CONNECTED) {
    webSocket.sendTXT(client, "{\"status\":\"connected\"}");
  } else if (type == WStype_DISCONNECTED) {
    // Do not automatically stop on a single client disconnect if multiple clients are used.
    // This prototype uses one browser client; fail safe by stopping outputs.
    allOff();
  } else if (type == WStype_TEXT) {
    StaticJsonDocument<512> doc;
    DeserializationError err = deserializeJson(doc, payload, length);
    if (err) {
      webSocket.sendTXT(client, "{\"status\":\"bad_json\"}");
      return;
    }
    bool stop = doc["stop"] | false;
    JsonArray jets = doc["jets"].as<JsonArray>();
    if (stop || jets.size() < JET_COUNT) {
      allOff();
      webSocket.sendTXT(client, "{\"status\":\"outputs_off\"}");
      return;
    }
    for (int i = 0; i < JET_COUNT; i++) {
      int v = constrain((int)(jets[i] | 0), 0, 100);
      jetValues[i] = (uint8_t)map(v, 0, 100, 0, 255);
      ledcWrite(jetPins[i], jetValues[i]);
    }
    webSocket.sendTXT(client, "{\"status\":\"running\"}");
  }
}

void setup() {
  Serial.begin(115200);
  for (int i = 0; i < JET_COUNT; i++) {
    ledcAttach(jetPins[i], PWM_FREQ, PWM_BITS); // ESP32 Arduino core 3.x
  }
  allOff();

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi");
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) {
    delay(400); Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWi-Fi connected");
    Serial.print("ESP32 IP: "); Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWi-Fi connection failed. Check SSID/password and restart.");
  }
  webSocket.begin();
  webSocket.onEvent(onWebSocketEvent);
  Serial.println("WebSocket server ready on port 81");
}

void loop() {
  webSocket.loop();
  if (WiFi.status() != WL_CONNECTED) allOff();
}